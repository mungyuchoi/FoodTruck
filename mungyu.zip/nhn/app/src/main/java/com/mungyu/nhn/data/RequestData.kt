package com.mungyu.nhn.data

data class RequestData(
    val type: String, //GET, POST, PUT, DELETE
    val timeout: Int,
    val requestHeaders: HashMap<String, String>,
    val query: String?,
    val url: String
)