package com.mungyu.nhn.data

const val compress_type = 1
const val related_type = 2