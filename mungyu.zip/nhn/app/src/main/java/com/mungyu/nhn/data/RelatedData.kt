package com.mungyu.nhn.data

data class RelatedData(
    val detail: ArrayList<RelatedDetail>
)

data class RelatedDetail(
    val title: String,
    val displayTitle: String,
    val thumbnail: String?
)