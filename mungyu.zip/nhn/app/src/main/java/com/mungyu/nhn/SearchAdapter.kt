package com.mungyu.nhn

import android.content.Context
import android.content.Intent
import android.os.Build
import android.text.Html
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.mungyu.nhn.data.SearchData
import com.mungyu.nhn.data.compress_type

class SearchAdapter(private val activity: MainActivity) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var datas = mutableListOf<SearchData>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        Log.i("MQ!", "onCreateViewHolder type:$viewType")
        val view: View?
        return when (viewType) {
            compress_type -> {
                view = LayoutInflater.from(activity)
                    .inflate(R.layout.compress_item, parent, false)
                SearchViewHolder(view)
            }
            else -> {
                view = LayoutInflater.from(activity)
                    .inflate(R.layout.related_item, parent, false)
                SearchViewHolder(view)
            }
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        Log.i("MQ!", "onBindViewHolder position:$position")
        when (datas[position].type) {
            compress_type -> {
                (holder as SearchViewHolder).bind(datas[position])
                holder.setIsRecyclable(false)
            }
            else -> {
                (holder as SearchViewHolder).bind(datas[position])
                holder.setIsRecyclable(false)
            }
        }
    }

    override fun getItemCount(): Int = datas.size

    override fun getItemViewType(position: Int): Int {
        return datas[position].type
    }

    inner class SearchViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val title: TextView = view.findViewById(R.id.title)
        private val description: TextView = view.findViewById(R.id.description)
        private val thumbnail: ImageView = view.findViewById(R.id.thumbnail)

        fun bind(item: SearchData) {
            title.text = item.title
            description.text = item.description.htmlToString()
            Glide.with(itemView).load(item.thumbnail).into(thumbnail)
            itemView.setOnClickListener {
                activity.startActivity(Intent(activity, WebViewActivity::class.java).apply {
                    putExtra("TITLE", item.title)
                })
            }
        }
    }
}

fun String.htmlToString(): String {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
        return Html.fromHtml(this, Html.FROM_HTML_MODE_LEGACY).toString()
    } else {
        return Html.fromHtml(this).toString()
    }
}
