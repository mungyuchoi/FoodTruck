package com.mungyu.nhn.network

import com.mungyu.nhn.data.CompressData

interface CompressDataReceive {
    fun onReceiveRun(data: CompressData)
}