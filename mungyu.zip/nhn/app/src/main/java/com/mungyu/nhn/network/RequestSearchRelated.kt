package com.mungyu.nhn.network

import android.os.Handler
import android.util.Log
import com.mungyu.nhn.data.CompressData
import com.mungyu.nhn.data.RelatedData
import com.mungyu.nhn.data.RelatedDetail
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class RequestSearchRelated(
    private val receive: RelatedDataReceive,
    private val txtResult: String?
) : Thread() {
    private val handler = Handler()
    override fun run() {
        try {
            val url = URL("$SEARCH_RELATED/$txtResult")

            val conn: HttpURLConnection = url.openConnection() as HttpURLConnection
            conn?.run {
                connectTimeout = 10000 // 10초 동안 기다린 후 응답이 없으면 종료
                requestMethod = "GET"
                doInput = true
                setRequestProperty("ContentType", "application/x-www-form-urlencoded")
            }
            val resCode: Int = conn.responseCode
            Log.i("MQ!", "RequestSearchRelated resCode: $resCode")
            if (resCode == HttpURLConnection.HTTP_OK) {
                val reader = BufferedReader(InputStreamReader(conn.inputStream))
                var line: String?
                val sb = StringBuilder()
                while (true) {
                    line = reader.readLine()
                    if (line == null) break
                    sb.append(line)
                }
                val jsonObject = JSONObject(sb.toString())
                Log.i("MQ!", "jsonObject:$jsonObject")
                var detail = arrayListOf<RelatedDetail>()
                jsonObject.run {
                    val page = getString("pages")
                    val jsonArray = JSONArray(page)
                    Log.i("MQ!", "length:${jsonArray.length()}, jsonArray:$jsonArray")
                    for (i in 0 until jsonArray.length()) {
                        jsonArray.getJSONObject(i).run {
                            val title = getString("title")
                            val displayTitle = getString("displaytitle")
                            val thumbnail = optString("thumbnail", "")
                            if (thumbnail != "") {
                                var thumbnailObject = JSONObject(thumbnail)
                                val data = RelatedDetail(
                                    title = title, displayTitle = displayTitle,
                                    thumbnail = thumbnailObject.getString("source")
                                )
                                detail.add(data)
                            } else {
                                val data = RelatedDetail(
                                    title = title, displayTitle = displayTitle,
                                    thumbnail = null
                                )
                                detail.add(data)
                            }
                        }
                    }
                    val relatedData = RelatedData(detail)

                    handler.post {
                        receive.onReceiveRun(relatedData)
                    }
                }
                reader.close()

            }
            conn.disconnect()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    companion object {
        private const val SEARCH_RELATED = "https://en.wikipedia.org/api/rest_v1/page/related"
    }
}