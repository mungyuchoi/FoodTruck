package com.mungyu.nhn.data

data class SearchData(
    val title: String,
    val description: String,
    val thumbnail: String?,
    val type: Int
)