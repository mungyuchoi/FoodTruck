package com.mungyu.nhn.network


interface DataReceive<T> {
    fun onReceiveRun(data: T)
}