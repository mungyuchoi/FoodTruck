package com.mungyu.nhn.data

data class CompressData(
    val title: String,
    val extractHtml: String,
    val thumbnail: String
)