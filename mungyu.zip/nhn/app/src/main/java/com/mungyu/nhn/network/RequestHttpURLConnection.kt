package com.mungyu.nhn.network

import android.os.Handler
import android.util.Log
import com.mungyu.nhn.MainActivity
import com.mungyu.nhn.data.CompressData
import com.mungyu.nhn.data.RequestData
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class RequestHttpURLConnection(
    private val activity: MainActivity,
    private val requestData: RequestData
) : Thread() {
    private val handler = Handler()

    override fun run() {
        try {
            val url = URL("${requestData.url}/${requestData.query}")

            val conn: HttpURLConnection = url.openConnection() as HttpURLConnection
            conn?.run {
                connectTimeout = requestData.timeout // 10초 동안 기다린 후 응답이 없으면 종료
                requestMethod = requestData.type
                doInput = true
                for ((key, value) in requestData.requestHeaders) {
                    setRequestProperty(key, value)
                }
            }
            val resCode: Int = conn.responseCode
            Log.i("MQ!", "RequestHttpURLConnection resCode: $resCode")
            if (resCode == HttpURLConnection.HTTP_OK) {
                val reader = BufferedReader(InputStreamReader(conn.inputStream))
                var line: String?
                val sb = StringBuilder()
                while (true) {
                    line = reader.readLine()
                    if (line == null) break
                    sb.append(line)
                }
                val jsonObject = JSONObject(sb.toString())
                jsonObject.run {
                    val thumbnailObject = JSONObject(getString("thumbnail"))
                    val data = CompressData(
                        title = getString("title"), extractHtml = getString("extract_html"),
                        thumbnail = thumbnailObject.getString("source")
                    )
                    handler.post {
                        activity.onReceiveRun(data)
                    }
                }
                reader.close()

            }
            conn.disconnect()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}