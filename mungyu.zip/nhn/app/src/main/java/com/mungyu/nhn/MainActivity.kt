package com.mungyu.nhn

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.inputmethod.InputMethodManager
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.recyclerview.widget.LinearLayoutManager
import com.mungyu.nhn.data.*
import com.mungyu.nhn.databinding.ActivityMainBinding
import com.mungyu.nhn.network.*

class MainActivity : AppCompatActivity(), CompressDataReceive, RelatedDataReceive {

    private lateinit var binding: ActivityMainBinding
    private lateinit var searchAdapter: SearchAdapter
    private var search: MenuItem? = null

    private var searchQuery: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.myToolbar)
        binding.swipeRefreshLayout.setOnRefreshListener {
            searchQuery?.run{
                RequestCompressInformation(this@MainActivity, this).start()
                RequestSearchRelated(this@MainActivity, this).start()
            }
            binding.swipeRefreshLayout.isRefreshing = false
        }
        binding.recyclerView.run {
            searchAdapter = SearchAdapter(this@MainActivity)
            adapter = searchAdapter
            layoutManager = LinearLayoutManager(this@MainActivity)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        super.onCreateOptionsMenu(menu)
        menuInflater.inflate(R.menu.menu, menu)
        search = menu?.findItem(R.id.item_search)?.apply {
            setOnActionExpandListener(object : MenuItem.OnActionExpandListener {
                override fun onMenuItemActionExpand(p0: MenuItem?): Boolean {
                    return true
                }

                override fun onMenuItemActionCollapse(p0: MenuItem?): Boolean {
                    return true
                }
            })
            (actionView as SearchView).run {
                isSubmitButtonEnabled = true
                setOnQueryTextListener(object : SearchView.OnQueryTextListener {
                    override fun onQueryTextSubmit(query: String?): Boolean {
                        Log.i("MQ!", "onQueryTextSubmit")
                        RequestCompressInformation(this@MainActivity, query).start()
                        RequestSearchRelated(this@MainActivity, query).start()

                        // Can use network library
//                        RequestHttpURLConnection(this@MainActivity, RequestData(type="GET", timeout = 10000, requestHeaders = HashMap<String,String>().apply {
//                            put("ContentType", "application/x-www-form-urlencoded")
//                        }, query = query, url = COMPRESS_INFORMATION)).start()
                        searchQuery = query
                        return true
                    }

                    override fun onQueryTextChange(newText: String?): Boolean {
                        receiveCompress = false
                        receiveRelated = false
                        searchQuery = newText
                        return true
                    }

                })
            }
        }

        return true
    }

    var compressData: CompressData? = null
    var relatedData: RelatedData? = null
    var datas = mutableListOf<SearchData>()
    var receiveCompress = false
    var receiveRelated = false

    override fun onReceiveRun(data: CompressData) {
        compressData = data
        receiveCompress = true
        if (receiveRelated) {
            zipData()
        }
    }

    override fun onReceiveRun(data: RelatedData) {
        relatedData = data
        receiveRelated = true
        if (receiveCompress) {
            zipData()
        }
    }

    fun zipData() {
        datas = arrayListOf<SearchData>().apply {
            // Compress
            add(
                SearchData(
                    title = compressData!!.title,
                    description = compressData!!.extractHtml,
                    thumbnail = compressData!!.thumbnail,
                    type = compress_type
                )
            )

            // Related
            for (i in relatedData!!.detail) {
                add(
                    SearchData(
                        title = i.title,
                        description = i.displayTitle,
                        thumbnail = i.thumbnail,
                        type = related_type
                    )
                )
            }
        }
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).run {
            hideSoftInputFromWindow(binding.myToolbar.windowToken, 0)
        }
        searchAdapter.datas = datas
        searchAdapter.notifyDataSetChanged()
        Log.i("MQ!", "zipData and notifyDataSetChanged")
    }

    companion object {
        private const val SEARCH_DETAIL = "https://en.wikipedia.org/api/rest_v1/page/html/"
        private const val SEARCH_RELATED = "https://en.wikipedia.org/api/rest_v1/page/related"
        private const val COMPRESS_INFORMATION =
            "https://en.wikipedia.org/api/rest_v1/page/summary"
    }
}