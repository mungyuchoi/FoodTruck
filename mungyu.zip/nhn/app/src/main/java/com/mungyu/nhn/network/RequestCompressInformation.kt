package com.mungyu.nhn.network

import android.os.Handler
import android.util.Log
import com.mungyu.nhn.data.CompressData
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

class RequestCompressInformation(
    private val receive: CompressDataReceive,
    private val txtResult: String?
) : Thread() {
    private val handler = Handler()
    override fun run() {
        try {
            val url = URL("$COMPRESS_INFORMATION/$txtResult")

            val conn: HttpURLConnection = url.openConnection() as HttpURLConnection
            conn?.run {
                connectTimeout = 10000 // 10초 동안 기다린 후 응답이 없으면 종료
                requestMethod = "GET"
                doInput = true
                setRequestProperty("ContentType", "application/x-www-form-urlencoded")
            }
            val resCode: Int = conn.responseCode
            Log.i("MQ!", "RequestCompressInformation resCode: $resCode")
            if (resCode == HttpURLConnection.HTTP_OK) {
                val reader = BufferedReader(InputStreamReader(conn.inputStream))
                var line: String?
                val sb = StringBuilder()
                while (true) {
                    line = reader.readLine()
                    if (line == null) break
                    sb.append(line)
                }
                val jsonObject = JSONObject(sb.toString())
                jsonObject.run {
                    val thumbnailObject = JSONObject(getString("thumbnail"))
                    val data = CompressData(
                        title = getString("title"), extractHtml = getString("extract_html"),
                        thumbnail = thumbnailObject.getString("source")
                    )
                    handler.post {
                        receive.onReceiveRun(data)
                    }
                }
                reader.close()

            }
            conn.disconnect()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    companion object {
        private const val COMPRESS_INFORMATION =
            "https://en.wikipedia.org/api/rest_v1/page/summary"
    }
}