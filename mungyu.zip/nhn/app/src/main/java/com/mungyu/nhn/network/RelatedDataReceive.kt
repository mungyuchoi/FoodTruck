package com.mungyu.nhn.network

import com.mungyu.nhn.data.RelatedData

interface RelatedDataReceive {
    fun onReceiveRun(data: RelatedData)
}